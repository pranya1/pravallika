package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.ICategoryDao;
import com.cg.model.Category;

@Service("iCategoryService")
public class ICategoryServiceImpl implements ICategoryService {

	@Autowired
	ICategoryDao iCategoryDao;

	public Category save(Category category) {
		return iCategoryDao.save(category);
	}


	@Override
	public void remove(Category category) {
		// TODO Auto-generated method stub
		iCategoryDao.delete(category);
	}


	@Override
	public List<Category> findAll() {
		// TODO Auto-generated method stub
		return iCategoryDao.findAll();
	}

}
