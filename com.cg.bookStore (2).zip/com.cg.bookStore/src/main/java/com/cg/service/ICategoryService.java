package com.cg.service;

import java.util.List;

import com.cg.model.Category;

public interface ICategoryService {

	public Category save(Category category);

	public void remove(Category category);

	public List<Category> findAll();

	public void delete(Category category);

}
