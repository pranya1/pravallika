package com.cg.dao;

import java.util.List;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.model.Category;

@Repository
public class CategoryDaoImpl implements ICategoryDao{
	
	@PersistenceContext
	EntityManager entityManager;


	@Override
	public Category save(Category category) {
		// TODO Auto-generated method stub
		entityManager.persist(category);
		System.out.println(category);
		return category ;
	}


	@Override
	public List<Category> findAll() {
	
		Query query= entityManager.createQuery("select c from Category c");
		
		System.out.println(query.getResultList());
		return query.getResultList();
	}


	@Override
	public void delete(Category category) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void table() {
		// TODO Auto-generated method stub
		System.out.println("helooooooo");
		Category category=new Category("tragedy");
		entityManager.persist(category);
	}



}
