package com.cg.dao;

import java.util.List;



import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.model.Category;

@Repository
@Transactional
public interface ICategoryDao {

	public Category save(Category category);

	//public void remove(Category category);

	public List<Category> findAll();

	public void delete(Category category);

	public void table();

}
