package com.cg.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.model.Admin;

import com.cg.service.IAdminService;


@RestController
public class LoginController {

	@Autowired
	IAdminService iAdminService;


	@RequestMapping(value = "/bookStore")
	public String start1() {
		return "home";
	}

	@RequestMapping(value = "/login/{loginType}", method = RequestMethod.GET)
	public String login(@PathVariable("loginType") String loginType, HttpServletRequest request, HttpSession session) {
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		if (loginType.equalsIgnoreCase("admin")) {
			Admin admin = iAdminService.findByEmail(email);
			if (admin != null) {
				if (admin.getPassword().equals(password)) {
					session.setAttribute("user", admin);
					return "admin login Successful";
				} else {
					return "wrong password";
				}
			} else {
				return "no admin exits";
			}
		}
		return password; 
	}

	@RequestMapping(value = "/changePassword/{changeType}", method = RequestMethod.GET)
	public String changePassword(@PathVariable("changeType") String changeType, HttpServletRequest request) {
		String newPassword = request.getParameter("newPassword");
		String confirmPassword = request.getParameter("confirmPassword");
		HttpSession session = request.getSession();
		if (changeType.equalsIgnoreCase("admin")) {
			Admin admin = (Admin) session.getAttribute("user");
			if (admin != null) {
				if (!newPassword.equalsIgnoreCase(confirmPassword)) {
					return "new password didnt match with old password";
				}
				admin.setPassword(newPassword);
				iAdminService.save(admin);
				return "your password changed Successfully";
			} else {
				return "Admin doesnot exist";
			}
		}
		return confirmPassword;
	}

	@PostMapping("/create_Admin")
	public Admin createCustomer(@RequestBody Admin admin) {
		iAdminService.save(admin);
		return admin;
	}

	@RequestMapping("/logout")
	public String logout(HttpServletRequest request) {
		HttpSession session = request.getSession();
		session.invalidate();
		return "logout Successful";
	}

}
