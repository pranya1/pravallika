package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.cg.dao.ICategoryDao;
import com.cg.model.Category;

import com.cg.service.ICategoryService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
public class BookController {

	@Autowired
	ICategoryService iCategoryService;

	@Autowired
	ICategoryDao iCategoryDao;

	@RequestMapping("/index")
	String index(){
		iCategoryDao.table();
		return "index";
	}

	@PostMapping("/add_Category")
	public Category add_Category(@RequestBody Category category) {
		System.out.println(category);
		iCategoryService.save(category);
		return category;
	}

	
	@RequestMapping("/listOfCategories")
	public List<Category> listOfCategories()
	{
		return iCategoryService.findAll();
	}
	
	
	

	@PostMapping("/delete_Category")
	public Category delete_Category(@RequestBody Category category) {
		System.out.println(category);
		iCategoryService.delete(category);
		return category;
	}
	

	

/*	@RequestMapping("/editCategory")
	public Category editCategory(@RequestParam("categoryId") int categoryId, Model model) {
		Category category = iCategoryService.findByCategoryId(categoryId);
		model.addAttribute("command", category);
		return category;
	}
*/
	@PostMapping("/updateCategory")
	public Category updateCategory(@ModelAttribute("category") Category category) {
		iCategoryService.save(category);
		return category;
	}
/*
	@RequestMapping("/deleteCategory")
	public String deleteCategory(@RequestParam("categoryId") int categoryId) {
		Category category = iCategoryService.findByCategoryId(categoryId);
		Category category1 = iCategoryService.findByCategory("NA");
		List<Book> booksOfCategory = iBookService.findByCategory(category);
		for (Book book : booksOfCategory) {
			book.setCategory(category1);
			iBookService.save(book);
		}
		iCategoryService.remove(category);
		return "Deleted Succesfully";
	}
*/
}
